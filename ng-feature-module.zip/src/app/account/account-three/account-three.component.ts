import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-account-three',
  templateUrl: './account-three.component.html',
  styleUrls: ['./account-three.component.css']
})
export class AccountThreeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
