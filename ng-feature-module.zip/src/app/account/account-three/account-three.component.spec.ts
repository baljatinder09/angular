import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountThreeComponent } from './account-three.component';

describe('AccountThreeComponent', () => {
  let component: AccountThreeComponent;
  let fixture: ComponentFixture<AccountThreeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AccountThreeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountThreeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
