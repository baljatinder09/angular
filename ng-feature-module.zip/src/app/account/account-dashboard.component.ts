import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-account-dashboard',
  templateUrl: './account-dashboard.component.html',
  })
export class AccountDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
