import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-account-two',
  templateUrl: './account-two.component.html',
  styleUrls: ['./account-two.component.css']
})
export class AccountTwoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
