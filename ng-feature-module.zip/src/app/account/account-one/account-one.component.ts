import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-account-one',
  templateUrl: './account-one.component.html',
  styleUrls: ['./account-one.component.css']
})
export class AccountOneComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
