import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AccountOneComponent } from './account-one/account-one.component';
import { AccountTwoComponent } from './account-two/account-two.component';
import { AccountThreeComponent } from './account-three/account-three.component';
import { AccountDashboardComponent } from './account-dashboard.component';



@NgModule({
  declarations: [AccountOneComponent, AccountDashboardComponent,AccountTwoComponent, AccountThreeComponent],
  imports: [
    CommonModule
  ]
})
export class AccountModule { }
