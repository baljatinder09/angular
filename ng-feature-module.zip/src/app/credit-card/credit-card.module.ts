import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CreditCardOneComponent } from './credit-card-one/credit-card-one.component';
import { CreditCardTwoComponent } from './credit-card-two/credit-card-two.component';
import { CreditCardDashboardComponent } from './credit-card-dashboard.component';



@NgModule({
  declarations: [CreditCardOneComponent, CreditCardTwoComponent,CreditCardDashboardComponent],
  imports: [
    CommonModule
  ]
})
export class CreditCardModule { }
