import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-credit-card-dashboard',
  templateUrl: './credit-card-dashboard.component.html',
})
export class CreditCardDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
