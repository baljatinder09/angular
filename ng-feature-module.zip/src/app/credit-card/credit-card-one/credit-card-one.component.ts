import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-credit-card-one',
  templateUrl: './credit-card-one.component.html',
  styleUrls: ['./credit-card-one.component.css']
})
export class CreditCardOneComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
