import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-credit-card-two',
  templateUrl: './credit-card-two.component.html',
  styleUrls: ['./credit-card-two.component.css']
})
export class CreditCardTwoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
