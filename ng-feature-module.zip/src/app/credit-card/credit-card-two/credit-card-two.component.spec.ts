import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreditCardTwoComponent } from './credit-card-two.component';

describe('CreditCardTwoComponent', () => {
  let component: CreditCardTwoComponent;
  let fixture: ComponentFixture<CreditCardTwoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreditCardTwoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreditCardTwoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
