import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AccountDashboardComponent } from './account/account-dashboard.component';
import { AccountModule } from './account/account.module';
import { CreditCardModule } from './credit-card/credit-card.module';
import { OffersModule } from './offers/offers.module';
import { ProfilesModule } from './profiles/profiles.module';
import { LandingComponent } from './landing/landing.component';

@NgModule({
  declarations: [
    AppComponent,
    LandingComponent,
   ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    AccountModule,
    CreditCardModule,
    OffersModule,
    ProfilesModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
