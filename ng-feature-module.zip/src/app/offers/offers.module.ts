import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OffersDashboardComponent } from './offers-dashboard.component';
import { OffersTwoComponent } from './offers-two/offers-two.component';
import { OffersOneComponent } from './offers-one/offers-one.component';



@NgModule({
  declarations: [OffersDashboardComponent, OffersTwoComponent, OffersOneComponent],
  imports: [
    CommonModule
  ]
})
export class OffersModule { }
