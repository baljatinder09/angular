import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-offers-two',
  templateUrl: './offers-two.component.html',
  styleUrls: ['./offers-two.component.css']
})
export class OffersTwoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
