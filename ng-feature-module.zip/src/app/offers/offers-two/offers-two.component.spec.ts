import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OffersTwoComponent } from './offers-two.component';

describe('OffersTwoComponent', () => {
  let component: OffersTwoComponent;
  let fixture: ComponentFixture<OffersTwoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OffersTwoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OffersTwoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
