import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-offers-dashboard',
  templateUrl: './offers-dashboard.component.html',
})
export class OffersDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
