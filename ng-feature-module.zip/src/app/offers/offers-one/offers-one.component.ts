import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-offers-one',
  templateUrl: './offers-one.component.html',
  styleUrls: ['./offers-one.component.css']
})
export class OffersOneComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
