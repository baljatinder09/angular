import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OffersOneComponent } from './offers-one.component';

describe('OffersOneComponent', () => {
  let component: OffersOneComponent;
  let fixture: ComponentFixture<OffersOneComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OffersOneComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OffersOneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
