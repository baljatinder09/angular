import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AccountDashboardComponent } from './account/account-dashboard.component';
import { CreditCardDashboardComponent } from './credit-card/credit-card-dashboard.component';
import { LandingComponent } from './landing/landing.component';
import { OffersDashboardComponent } from './offers/offers-dashboard.component';
import { ProfilesDashboardComponent } from './profiles/profiles-dashboard.component';


const routes: Routes = [
{path:'',redirectTo:'home',pathMatch:'full'},
{path:'home',component:LandingComponent},
{path:'account',component:AccountDashboardComponent},
{path:'creditcard',component:CreditCardDashboardComponent},
{path:'offers',component:OffersDashboardComponent},
{path:'profiles',component:ProfilesDashboardComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
