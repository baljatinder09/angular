import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profiles-dashboard',
  templateUrl: './profiles-dashboard.component.html',
})
export class ProfilesDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
