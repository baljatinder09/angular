import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profiles-one',
  templateUrl: './profiles-one.component.html',
  styleUrls: ['./profiles-one.component.css']
})
export class ProfilesOneComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
