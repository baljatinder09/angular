import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfilesOneComponent } from './profiles-one.component';

describe('ProfilesOneComponent', () => {
  let component: ProfilesOneComponent;
  let fixture: ComponentFixture<ProfilesOneComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProfilesOneComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProfilesOneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
