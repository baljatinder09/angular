import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProfilesDashboardComponent } from './profiles-dashboard.component';
import { ProfilesOneComponent } from './profiles-one/profiles-one.component';
import { ProfilesTwoComponent } from './profiles-two/profiles-two.component';



@NgModule({
  declarations: [ProfilesDashboardComponent, ProfilesOneComponent, ProfilesTwoComponent],
  imports: [
    CommonModule
  ]
})
export class ProfilesModule { }
