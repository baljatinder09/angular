import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profiles-two',
  templateUrl: './profiles-two.component.html',
  styleUrls: ['./profiles-two.component.css']
})
export class ProfilesTwoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
