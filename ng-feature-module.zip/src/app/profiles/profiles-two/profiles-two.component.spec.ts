import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfilesTwoComponent } from './profiles-two.component';

describe('ProfilesTwoComponent', () => {
  let component: ProfilesTwoComponent;
  let fixture: ComponentFixture<ProfilesTwoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProfilesTwoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProfilesTwoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
