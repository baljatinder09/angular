import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Product';
  
  AppComponent(){
    window.alert(this.title);
 // window.alert(sessionStorage.getItem('message'));
}}
