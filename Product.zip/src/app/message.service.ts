import { Injectable } from '@angular/core';

@Injectable()
//({
 // providedIn: 'root'
//})
export class MessageService {
  messages:string[]=[];
  //localStorage:any;
  
  constructor() { }

addMessage(message:string)
{
  this.messages.push(message);
  sessionStorage.setItem('message', JSON.stringify(this.messages));
 // alert(sessionStorage.getItem('message'));
}
clear()
{
  this.messages=[];
}
}
