import { Component, OnInit } from '@angular/core';
import { HeroService } from '../hero.service';
import { MessageService } from '../message.service';
import { Hero } from './Hero';


@Component({
  selector: 'app-heroes',
  templateUrl: './heroes.component.html',
  styleUrls: ['./heroes.component.css']
})
export class HeroesComponent implements OnInit {
  public heroes:Hero[];
  selectedHero:Hero;
  constructor(private heroService:HeroService,private messageService: MessageService) {
   // window.alert("constructor !");
   }

  ngOnInit(): void {
   // window.alert("ngOnInit !");
   this.getHeroes();
  }
  getHeroes(): void {
    //window.alert("hellow");
    //this.heroes = this.heroService.getHeroes();
    this.heroService.getHeroes().subscribe(heroes =>this.heroes=heroes);
  }
  onSelect(hero:Hero)
  {
    this.selectedHero=hero;
    this.messageService.addMessage(`HeroesComponent: Selected hero id=${hero.id}`);   
  }
}
