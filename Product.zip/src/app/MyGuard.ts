import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot, UrlTree } from "@angular/router";
import { Observable } from 'rxjs';

class MyGuard  implements CanActivate
{
    canActivate() {
        return false;
      }
}