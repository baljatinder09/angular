export interface Product{
       productId:number;
       title:string;
       description:string;
       price:string;
       imagePath:string
   }
   export const PRODUCTS=[
        {productId:1004,title:'Samsung Galaxy S9 Plus',description:'Samsung Galaxy S9 Plus (Midnight Black, 6GB RAM, 64GB Storage) with Offer',price:'27,899.00',imagePath:'samsung-galaxy-s9-plus.jpeg'},
        {productId:1005,title:'Samsung Galaxy M31',description:'Samsung Galaxy M31 (Ocean Blue, 6GB RAM, 128GB Storage)',price:'16,499.00',imagePath:'samsung-galaxy-s9-plus.jpeg'},
        {productId:1006,title:'Samsung Galaxy M51',description:'Samsung Galaxy M51 (Electric Blue, 8GB RAM, 128GB Storage)',price:'24,999.00 ',imagePath:'samsung-galaxy-s9-plus.jpeg'},
        {productId:1007,title:'Samsung Galaxy M31',description:'Samsung Galaxy M31 (Space Black, 6GB RAM, 128GB Storage)',price:'16,499.00',imagePath:'samsung-galaxy-s9-plus.jpeg'},
        {productId:1008,title:'Samsung Galaxy S10 Plus',description:'Samsung Galaxy S10 Plus (Prism Black, 8GB RAM, 128GB Storage)',price:'65,199.72',imagePath:'samsung-galaxy-s9-plus.jpeg'},
        {productId:1009,title:'Samsung Galaxy S21 5G',description:'Samsung Galaxy S21 5G (Phantom Gray, 8GB, 256GB Storage) with No Cost EMI/Additional Exchange Offers',price:'73,999.00',imagePath:'samsung-galaxy-s9-plus.jpeg'},
        {productId:1010,title:'Samsung Galaxy S21 Plus 5G',description:'Samsung Galaxy S21 Plus 5G (Phantom Black, 8GB, 128GB Storage) with No Cost EMI/Additional Exchange Offers',price:'81,999.00',imagePath:'samsung-galaxy-s9-plus.jpeg'},
    ];
