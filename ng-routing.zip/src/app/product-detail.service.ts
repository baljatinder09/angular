import { Injectable } from '@angular/core';
import { Product } from './models/product';
import { PRODUCTS } from './models/product';
import {Observable,of} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductDetailService {

  constructor() { }

public getProduct(productId:number):Observable <Product>
{
//let books:Book[]=this.getProducts();
return of(PRODUCTS.find(p => p.productId==productId));
}
}

