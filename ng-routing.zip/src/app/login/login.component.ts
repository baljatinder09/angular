import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
  }
  forgetPassword():void
  {
    this.router.navigate(['/forgetpassword']);
  }
  doLogin(loginForm:NgForm)
  {
    alert(loginForm.value.userName);
  }
}
