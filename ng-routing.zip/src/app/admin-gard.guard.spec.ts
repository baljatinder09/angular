import { TestBed } from '@angular/core/testing';

import { AdminGardGuard } from './admin-gard.guard';

describe('AdminGardGuard', () => {
  let guard: AdminGardGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    guard = TestBed.inject(AdminGardGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
