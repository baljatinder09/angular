import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { ForgetPasswordComponent } from './forget-password/forget-password.component';
import { AdminComponent } from './admin/admin.component';
import { ProductsComponent } from './products/products.component';
import { ProductsDetailComponent } from './products-detail/products-detail.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { SpecificationComponent } from './products-detail/specification/specification.component';
import { TechnicalDetailsComponent } from './products-detail/technical-details/technical-details.component';
import { AdditionalInformationComponent } from './products-detail/additional-information/additional-information.component';
import { HeadingComponent } from './heading/heading.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    ForgetPasswordComponent,
    AdminComponent,
    ProductsComponent,
    ProductsDetailComponent,
    PageNotFoundComponent,
    SpecificationComponent,
    TechnicalDetailsComponent,
    AdditionalInformationComponent,
    HeadingComponent    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
