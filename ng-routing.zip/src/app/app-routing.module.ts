import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminGardGuard } from './admin-gard.guard';
import { ForgetPasswordComponent } from './forget-password/forget-password.component';
import { LoginComponent } from './login/login.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { AdditionalInformationComponent } from './products-detail/additional-information/additional-information.component';
import { ProductsDetailComponent } from './products-detail/products-detail.component';
import { SpecificationComponent } from './products-detail/specification/specification.component';
import { TechnicalDetailsComponent } from './products-detail/technical-details/technical-details.component';
import { ProductsComponent } from './products/products.component';


const routes: Routes = [
{path:'',redirectTo:'login',pathMatch: 'full'},
{path:'login',component:LoginComponent},
{path:'forgetpassword',component:ForgetPasswordComponent},
{path:'products',component:ProductsComponent,
children:[{path:'productdetail/:id',component:ProductsDetailComponent,canActivate:[AdminGardGuard],
  children:[
          {path:'',redirectTo:'specificiation',pathMatch:'full'},
          {path:'specificiation',component:SpecificationComponent},
          {path:'technicaldetail',component:TechnicalDetailsComponent},
          {path:'additionalinformation',component:AdditionalInformationComponent}
          ]
}]
},
{path:'**',component:PageNotFoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes,{ useHash: true ,enableTracing: true})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
