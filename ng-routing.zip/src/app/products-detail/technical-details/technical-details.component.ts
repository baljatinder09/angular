import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-technical-details',
  templateUrl: './technical-details.component.html',
  styleUrls: ['./technical-details.component.css']
})
export class TechnicalDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
