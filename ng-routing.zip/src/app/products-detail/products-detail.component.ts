import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { of } from 'rxjs';
import { Product, PRODUCTS } from '../models/product';
import { ProductDetailService } from '../product-detail.service';

@Component({
  selector: 'app-products-detail',
  templateUrl: './products-detail.component.html',
  styleUrls: ['./products-detail.component.css']
})
export class ProductsDetailComponent implements OnInit {

  productId;
  product:Product;
  constructor(private productDetailService:ProductDetailService,private activeRouter:ActivatedRoute) { 
    
  }

  ngOnInit(): void {
    this.activeRouter.params.subscribe(
      parameter => {
        this.productId=parameter['id'];
        this.findProduct(this.productId);
      } );
      
   }

   public findProduct(productId):void
   {
    this.productDetailService.getProduct(productId).subscribe(data => this.product=data);
   }
}
