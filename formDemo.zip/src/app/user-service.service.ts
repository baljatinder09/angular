import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Users } from './name-editor/Classes';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {
constructor(private httpService:HttpClient) { }

public getUser():Observable<Users>
{
  //let Users:Observable<Users>
   return this.httpService.get<Users>("./name-editor/user.json");
}
}
