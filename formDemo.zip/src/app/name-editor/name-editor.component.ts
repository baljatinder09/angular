import { Component, OnInit } from '@angular/core';
import {FormControl} from '@angular/forms'
import { Car,Users,Address,Geo } from './Classes';
import { UserServiceService } from '../user-service.service';
import { HttpEventType } from '@angular/common/http';

 
@Component({
  selector: 'app-name-editor',
  templateUrl: './name-editor.component.html',
  styleUrls: ['./name-editor.component.css']
})
export class NameEditorComponent implements OnInit {

   myDate:any=new Date().getFullYear()-14;

address:any[]=[{'name':'hello'},{'name':'how'},{'name':'are'},{'name':'you'}];


//usersObj45:Users=[{'id': 1},{'name': 'Leanne Graham'},{'username': 'Antonette'},{'email': 'Sincere@april.biz'},{address:[{'street': 'Kulas Light'},{'suite': 'Apt. 556'},{'city': 'Gwenborough'},{'zipcode': 929983874}]},{geo: [{'lat': '-37.3159'},{'lng': '81.1496'}]}];
usersObj:Users;
//={'id': 1,'name': 'Leanne Graham','username': 'Antonette','email': 'Sincere@april.biz',address:{'street': 'Kulas Light','suite': 'Apt. 556','city': 'Gwenborough','zipcode': 929983874},geo:{'lat': '-37.3159','lng': '81.1496'}};

  name = new FormControl('');
  serverId:number=10;
  allowButton:boolean=false;
  serverStatus:string="Ofline";
  constructor(private userServiceService:UserServiceService ) { }

//obj=new Car(5);
resultData:String="Server Resrult Data";
getServerStatus():string
{
  return this.serverStatus;
}

  ngOnInit(): void {
   console.log("init Call");
   this.userServiceService.getUser().subscribe(
    data => this.usersObj=data   );
    }
  updateName():void
  {
    this.name.setValue("jatinder Singh");
  }
  updateResult(event:Event):void
  {
    this.resultData=(<HTMLInputElement>event.target).value;
    console.log((<HTMLInputElement>event.target).value);
  }
}
