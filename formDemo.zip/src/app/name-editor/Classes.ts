export class Car
{
    private speed:number;
    Car(speed:number)
    {
        this.speed=speed || 0;
    }
    acclerator():void
    {
         this.speed++;
    }
    throttle():void
    {
        this.speed--;
    }
    getSpeed():void
    {
        console.log(this.speed);
    }}

export interface  Users
{
    id:number;
    name:string;
    username:string;
    email:String;
    address:Address;
    geo:Geo;
}
export interface Address{
    street:String;
    suite:String;
    city:string;
    zipcode:number;
}
export interface Geo{
    lat:String;
    lng:String;
}