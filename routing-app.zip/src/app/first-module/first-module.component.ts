import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BookService } from '../book.service';
import { Book } from '../books';

@Component({
  selector: 'app-first-module',
  templateUrl: './first-module.component.html',
  styleUrls: ['./first-module.component.css']
})
export class FirstModuleComponent implements OnInit {

  id:string;
  books:Book[];
  constructor(private route:ActivatedRoute,private routeNav:Router,private bookService:BookService) { }

  ngOnInit(): void {
  this.bookService.getProducts().subscribe(response => this.books=response);
    this.route.paramMap.subscribe(params =>
    { this.id=params.get("id");})
    this.id=this.route.snapshot.paramMap.get("id");
  }
  goBack():void
  {
    //window.alert('call');
    this.routeNav.navigate(['home']);
//alert(this.routeNav.url);
  }
   
}
