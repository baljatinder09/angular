import { Injectable } from '@angular/core';
import { LoggerService } from './logger.service';

@Injectable()
export class ProductService {

  constructor(private logger:LoggerService) { 
   logger.log("Product Service Call");
  }

  callLogger():void
  {
    this.logger.log("CallLogger");
  }
}
