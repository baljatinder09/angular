import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BookService } from '../book.service';
import { Book } from '../books';

@Component({
  selector: 'app-book-detail',
  templateUrl: './book-detail.component.html',
  styleUrls: ['./book-detail.component.css']
})
export class BookDetailComponent implements OnInit ,OnDestroy{

  book:Book;
  id:number;
  sub;
  constructor(private router:Router,private bookService:BookService,private activeRouter:ActivatedRoute) { }
  

  ngOnInit(): void {
   // this.id=+this.activeRouter.snapshot.paramMap.get("id");
   this.sub=this.activeRouter.params.subscribe(params => 
    { 
      this.id= params['id']
   // this.book=this.bookService.getBook(this.id);
    this.bookService.getBook(this.id).subscribe(data => this.book=data);
    });
   // alert(this.book);
  }
  goBack():void{
    this.router.navigate(['/books'])

  }
  ngOnDestroy(): void {
    this.sub.unsubscribe();
  }
  
}
