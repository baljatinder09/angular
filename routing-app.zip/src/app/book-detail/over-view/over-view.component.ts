import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { BookService } from 'src/app/book.service';
import { Book } from 'src/app/books';

@Component({
  selector: 'app-over-view',
  templateUrl: './over-view.component.html',
  styleUrls: ['./over-view.component.css']
})
export class OverViewComponent implements OnInit {

  book:Book;
  id:number;
  constructor(private bookService:BookService,private activeRouter: ActivatedRoute) { }

  ngOnInit(): void {
    //alert('ngOnInit call');
this.activeRouter.parent.paramMap.subscribe(params =>
  {
    this.id=+params.get('id');
    //alert(this.id);
    this.bookService.getBook(this.id).subscribe(data => this.book=data);
    //alert(this.book.description);
  }
  
  
  )


  }



}
