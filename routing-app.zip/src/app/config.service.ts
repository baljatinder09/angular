import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
import {Config} from './config'

@Injectable({
  providedIn: 'root'
})
export class ConfigService {
  
  configUrl:string='assets/config.json';
  constructor(public http:HttpClient) { 
  }
  //const options = {
   // responseType: 'text',
  //};
  httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/text' }),
    headersParam: new HttpParams().append('_page', '1')
  };

  public callHttp() :Observable<Config>
  {
    return this.http.get<Config>(this.configUrl,this.httpOptions)
    .pipe( retry(3),catchError(this.handleError)) ;//x.pipe(this.errorHandleer);
  }
  private  handleError(error:HttpErrorResponse)
  {
    let errorMessag;
    switch (error.status) {
      case 404: {
        errorMessag= `Not Found: ${error.message}`;
      }
      case 403: {
        errorMessag= `Access Denied: ${error.message}`;
      }
      case 500: {
        errorMessag= `Internal Server Error: ${error.message}`;
      }
      default: {
        errorMessag= `Unknown Server Error: ${error.message}`;
      }  }
    return throwError(errorMessag);
  }
  public getServerErrorMessage(error: HttpErrorResponse): string {
    alert(error.status);
    switch (error.status) {
        case 404: {
            return `Not Found: ${error.message}`;
        }
        case 403: {
            return `Access Denied: ${error.message}`;
        }
        case 500: {
            return `Internal Server Error: ${error.message}`;
        }
        default: {
            return `Unknown Server Error: ${error.message}`;
        }
    }
  }
}
