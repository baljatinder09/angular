import { Book } from "./books";

export const LISTOFBOOKS:Book[]=[
    new Book(1001,'Murder Unleashed','Murder Unleashed (Dead-End Job Mysteries, Book 5)',100.3),
    new Book(1002,'Murder Between the Covers','Murder Between the Covers (Dead-End Job Mysteries, Book 2)',130.3),
    new Book(1004,'Dutch Hex','Dutch Hex: A Taylor Quinn Quilt Shop Mystery',160.3),
    new Book(1006,'Java','Java Sun certified Book',360.3),
];
