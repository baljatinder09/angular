import { BrowserModule } from '@angular/platform-browser';
import { NgModule,APP_INITIALIZER  } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FirstModuleComponent } from './first-module/first-module.component';
import { SecondModuleComponent } from './second-module/second-module.component';
import { ThirdModuleComponent } from './third-module/third-module.component';
import { HomeComponent } from './home/home.component';
import { BookDetailComponent } from './book-detail/book-detail.component';
import { OverViewComponent } from './book-detail/over-view/over-view.component';
import { SpecificationComponent } from './book-detail/specification/specification.component';
import { FormsModule } from '@angular/forms';
import { MoviesComponent } from './movies/movies.component';
import { NgclassComponent } from './ngclass/ngclass.component';
import {HttpClientModule} from'@angular/common/http';
import { ConfigService } from './config.service';
import { AppConfigService } from './app-config.service';
import { InjectableComponent } from './injectable/injectable.component';
import { ProductService } from './product.service';
import { LoggerService } from './logger.service';

@NgModule({
  declarations: [
    AppComponent,
    FirstModuleComponent,
    SecondModuleComponent,
    ThirdModuleComponent,
    HomeComponent,
    BookDetailComponent,
    OverViewComponent,
    SpecificationComponent,
    MoviesComponent,
    NgclassComponent,
    InjectableComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [ConfigService,ProductService,LoggerService,AppConfigService, { provide: APP_INITIALIZER,useFactory: initializeApp, deps: [AppConfigService], multi: true}
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
export function initializeApp(appConfigService: AppConfigService) {
  return (): Promise<any> => { 
    return appConfigService.load();
  }
}