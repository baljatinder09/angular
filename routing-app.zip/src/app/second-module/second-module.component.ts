import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-second-module',
  templateUrl: './second-module.component.html',
  styleUrls: ['./second-module.component.css']
})
export class SecondModuleComponent implements OnInit {

  name:string;
  id:string;
  id2:string;
  num:string;
  constructor(private activeRoute:ActivatedRoute) { }

  ngOnInit(): void {
    this.name=this.activeRoute.snapshot.paramMap.get("name");
    this.id=this.activeRoute.snapshot.paramMap.get("id");
    this.id2=this.activeRoute.snapshot.paramMap.get("id2");
  }

}
