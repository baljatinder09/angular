import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-movies',
  templateUrl: './movies.component.html',
  styleUrls: ['./movies.component.css']
})
export class MoviesComponent implements OnInit {

  constructor() { }
   title:String="Top 5 Movies";
  ngOnInit(): void {
  }
  movies:Movie[]=[
 new Movie('Zootopia','Byron Howard, Rich Moore','Idris Elba, Ginnifer Goodwin, Jason Bateman','March 4, 2016'),
 new Movie('Batman v Superman: Dawn of Justice','BZack Snyder','Ben Affleck, Henry Cavill, Amy Adams','March 25, 2016'),
 new Movie('Captain American: Civil War','Anthony Russo, Joe Russo','Scarlett Johansson, Elizabeth Olsen, Chris Evans','May 6, 2016'),
 new Movie('X-Men: Apocalypse','Bryan Singer','Jennifer Lawrence, Olivia Munn, Oscar Isaac','May 27, 2016'),
 new Movie('Warcraft','Duncan Jones','Travis Fimmel, Robert Kazinsky, Ben Foster','June 10, 2016'),
   ]
}
class Movie
{
  constructor(title:string,director:string,cast:string,releaseDate:string)
  {
    this.title=title;
    this.cast=cast;
    this.releaseDate=releaseDate;
    this.director=director;
  }
  title:string;
  director:string;
  cast:string;
  releaseDate:string;
}