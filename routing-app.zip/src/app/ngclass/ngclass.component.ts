import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ngclass',
  templateUrl: './ngclass.component.html',
  styleUrls: ['./ngclass.component.css']
})
export class NgclassComponent implements OnInit {

  constructor() { }

  ngcolorClass:Color=new Color()

  ngOnInit(): void {
  }

   toggleClass():void
   {
     if(this.ngcolorClass.red && this.ngcolorClass.size20)
     {
       alert('call');
      this.ngcolorClass.red=false;
      this.ngcolorClass.size20=false;
     }
     else
     {
       this.ngcolorClass.red=true;
       this.ngcolorClass.size20=true;
     }
   }


}
class Color
{
  red:boolean=false;
  size20:boolean=true;
}
