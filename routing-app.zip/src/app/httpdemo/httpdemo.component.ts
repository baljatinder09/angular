import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Config } from '../config';
import { ConfigService } from '../config.service';
import { environment } from '../../environments/environment';
import { AppConfigService } from '../app-config.service';

@Component({
  selector: 'app-httpdemo',
  templateUrl: './httpdemo.component.html',
  styleUrls: ['./httpdemo.component.css']
})
export class HttpdemoComponent implements OnInit {
  configUrl:string;
  protected apiServer = AppConfigService.settings.apiServer;
  constructor(private http:HttpClient,private configService:ConfigService) {
    alert(environment.apiEndPoint);
    this.configUrl=environment.apiEndPoint;
    console.log(this.apiServer.link1);
    console.log(this.apiServer.link2);
   }

  ngOnInit(): void {
  }
  config:Config=null;
   errorMessage:String="";
  //configUrl:string='assets/config.json';
   callHttp():void
  {

    this.configService.callHttp().subscribe(
        (data) =>  
            {
              this.config=data
            },
        (error) => 
        {
          console.log("Request failed with error");
          this.errorMessage=error;
           }   );
    alert('call');
    //this.http.get<Config>(this.configUrl).subscribe(data => this.config=data);
    console.log(this.config);
  }

}
