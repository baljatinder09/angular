import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-injectable',
  templateUrl: './injectable.component.html',
  styleUrls: ['./injectable.component.css']
})
export class InjectableComponent implements OnInit {

  constructor(private productService:ProductService) { }

  ngOnInit(): void {
  }
  call():void
  {
    this.productService.callLogger();
  } 
}
