import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-third-module',
  templateUrl: './third-module.component.html',
  styleUrls: ['./third-module.component.css']
})
export class ThirdModuleComponent implements OnInit {


  cities:string[]=["New Your","Delhi","Noida","London"];

  citiesArray:Array<string>=["New Your","Delhi","Noida","London"];
  constructor() { }
   items:Item[]=[{name:'',value:0},{name:'One',value:1},{name:'Two',value:2},{name:'Three',value:3},{name:'Four',value:4},{name:'Five',value:5},{name:'Six',value:6}]
   selectedValue:number;
   ngOnInit(): void {
  }

}
class Item
{
 name:string;
 value:number;
}
