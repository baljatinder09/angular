export interface IAppConfig {
 
    env: {
        name: string
    }
 
    apiServer: {
        link1:string,
        link2:string,
    }
}