export class Book
{
    bookId:number;
    bookName:string;
    description:string;
    price:number;
    constructor(bookId:number,bookName:string,description:string,price:number)
    {
        this.bookId=bookId;
        this.bookName=bookName;
        this.description=description;
        this.price=price;
    }
}