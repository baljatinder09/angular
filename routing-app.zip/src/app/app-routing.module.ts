import { NgClass } from '@angular/common';
import { Injectable, NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BookDetailComponent } from './book-detail/book-detail.component';
import { OverViewComponent } from './book-detail/over-view/over-view.component';
import { SpecificationComponent } from './book-detail/specification/specification.component';
import { FirstModuleComponent } from './first-module/first-module.component';
import { HomeComponent } from './home/home.component';
import { HttpdemoComponent } from './httpdemo/httpdemo.component';
import { InjectableComponent } from './injectable/injectable.component';
import { MoviesComponent } from './movies/movies.component';
import { NgclassComponent } from './ngclass/ngclass.component';
import { SecondModuleComponent } from './second-module/second-module.component';
import { ThirdModuleComponent } from './third-module/third-module.component';


const routes: Routes = [
  {path:'firstModule/:id/detail', component:FirstModuleComponent},
  {path:'books', component:FirstModuleComponent,
     children:[
              {path:'bookdetail/:id', component:BookDetailComponent,
              children: [
                         {path:'overview', component:OverViewComponent},
                         {path:'spec', component:SpecificationComponent},
                         {path: '', redirectTo:'spec', pathMatch:"full" }]}
              ]},
  {path:'secondModule', component:SecondModuleComponent},
  {path:'thirdModule',component:ThirdModuleComponent},
  {path:'home',component:HomeComponent},
  {path:'movies',component:MoviesComponent},
  {path:'ngClass',component:NgclassComponent},  
  {path:'httpdemo',component:HttpdemoComponent},
  {path:'injectable',component:InjectableComponent}, 
  {path:'',redirectTo:'/home',pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
