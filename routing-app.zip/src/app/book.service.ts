import { Injectable } from '@angular/core';
import { Observable , of } from 'rxjs';
import { Book } from './books';
import { LISTOFBOOKS } from './mock-books';

@Injectable({
  providedIn: 'root'
})
export class BookService {


  getProducts():Observable<Book[]>
  {

  //this.books=[
   // new Book(1001,'Murder Unleashed','Murder Unleashed (Dead-End Job Mysteries, Book 5)',100.3),
   // new Book(1002,'Murder Between the Covers','Murder Between the Covers (Dead-End Job Mysteries, Book 2)',130.3),
   // new Book(1004,'Dutch Hex','Dutch Hex: A Taylor Quinn Quilt Shop Mystery',160.3),
  //];
  return of(LISTOFBOOKS);
}Book
public getBook(id:number):Observable <Book>
{
//let books:Book[]=this.getProducts();
return of(LISTOFBOOKS.find(b => b.bookId==id));
}
}
